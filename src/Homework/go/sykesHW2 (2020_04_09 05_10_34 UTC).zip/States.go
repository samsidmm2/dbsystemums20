// Name: Sidney Sykes
// Course Number: CSCI475
// Assignment: Homework 2
// Honor Code: In keeping with the Honor Code of the University of Mississippi, I have neither given nor received inappropriate assistance on this assignment.

package main
import (
	"log"
	"net/http"
	"text/template"
	"strconv"
	"strings"
)

type State struct{
	Num int64
	Name string
	Abbr string
	Capital string
	Est int64
	Pop int64
	Reps int64
}

var tmpl = template.Must(template.ParseGlob("templates/*"))

func ChooseState2020(w http.ResponseWriter,r *http.Request) {
	// Define a State slice called Colonies
	Colonies := []State{}
	Colonies = append(Colonies, State{Num: 1, Name: "Delaware", Abbr: "DE", Capital: "Dover", Est: 1787, Pop: 973764, Reps: 1})
	Colonies = append(Colonies, State{Num: 2, Name: "Pennsylvania", Abbr: "PA", Capital: "Harrisburg", Est: 1787, Pop: 12801989, Reps: 18})
	Colonies = append(Colonies, State{Num: 3, Name: "New Jersey", Abbr: "NJ", Capital: "Trenton", Est: 1787, Pop: 8882190, Reps: 12})
	Colonies = append(Colonies, State{Num: 4, Name: "Georgia", Abbr: "GA", Capital: "Atlanta", Est: 1788, Pop: 10617423, Reps: 14})
	Colonies = append(Colonies, State{Num: 5, Name: "Connecticut", Abbr: "CT", Capital: "Hartford", Est: 1788, Pop: 3565278, Reps: 5})
	Colonies = append(Colonies, State{Num: 6, Name: "Massachusetts", Abbr: "MA", Capital: "Boston", Est: 1788, Pop: 6892503, Reps: 9})
	Colonies = append(Colonies, State{Num: 7, Name: "Maryland", Abbr: "MD", Capital: "Annapolis", Est: 1788, Pop: 6045680, Reps: 8})
	Colonies = append(Colonies, State{Num: 8, Name: "South Carolina", Abbr: "SC", Capital: "Columbia", Est: 1788, Pop: 5148714, Reps: 7})
	Colonies = append(Colonies, State{Num: 9, Name: "New Hampshire", Abbr: "NH", Capital: "Concord", Est: 1788, Pop: 1359711, Reps: 2})
	Colonies = append(Colonies, State{Num: 10, Name: "Virginia", Abbr: "VA", Capital: "Richmond", Est: 1788, Pop: 8535519, Reps: 11})
	Colonies = append(Colonies, State{Num: 11, Name: "New York", Abbr: "NY", Capital: "Albany", Est: 1788, Pop: 19453561, Reps: 27})
	Colonies = append(Colonies, State{Num: 12, Name: "North Carolina", Abbr: "NC", Capital: "Raleigh", Est: 1789, Pop: 10488084, Reps: 13})
	Colonies = append(Colonies, State{Num: 13, Name: "Rhode Island", Abbr: "RI", Capital: "Providence", Est: 1790, Pop: 1059361, Reps: 2})

	tmpl.ExecuteTemplate(w, "chooseState2020.html", Colonies)
}

func main() {
	log.Println("Server started on: http://localhost:8110")
		http.HandleFunc("/",ChooseState2020)
		http.HandleFunc("/listState2020.html",ListState2020)
		http.Handle("/home/swsykes/static/",http.StripPrefix("/home/swsykes/static/", http.FileServer(http.Dir("static"))))
		http.ListenAndServe(":8110", nil)

	}

	func ListState2020(w http.ResponseWriter, r *http.Request) {
		// Define and populate Colonies slice
		Colonies := []State{}
		Colonies = append(Colonies, State{Num: 1, Name: "Delaware", Abbr: "DE", Capital: "Dover", Est: 1787, Pop: 973764, Reps: 1})
		Colonies = append(Colonies, State{Num: 2, Name: "Pennsylvania", Abbr: "PA", Capital: "Harrisburg", Est: 1787, Pop: 12801989, Reps: 18})
		Colonies = append(Colonies, State{Num: 3, Name: "New Jersey", Abbr: "NJ", Capital: "Trenton", Est: 1787, Pop: 8882190, Reps: 12})
		Colonies = append(Colonies, State{Num: 4, Name: "Georgia", Abbr: "GA", Capital: "Atlanta", Est: 1788, Pop: 10617423, Reps: 14})
		Colonies = append(Colonies, State{Num: 5, Name: "Connecticut", Abbr: "CT", Capital: "Hartford", Est: 1788, Pop: 3565278, Reps: 5})
		Colonies = append(Colonies, State{Num: 6, Name: "Massachusetts", Abbr: "MA", Capital: "Boston", Est: 1788, Pop: 6892503, Reps: 9})
		Colonies = append(Colonies, State{Num: 7, Name: "Maryland", Abbr: "MD", Capital: "Annapolis", Est: 1788, Pop: 6045680, Reps: 8})
		Colonies = append(Colonies, State{Num: 8, Name: "South Carolina", Abbr: "SC", Capital: "Columbia", Est: 1788, Pop: 5148714, Reps: 7})
		Colonies = append(Colonies, State{Num: 9, Name: "New Hampshire", Abbr: "NH", Capital: "Concord", Est: 1788, Pop: 1359711, Reps: 2})
		Colonies = append(Colonies, State{Num: 10, Name: "Virginia", Abbr: "VA", Capital: "Richmond", Est: 1788, Pop: 8535519, Reps: 11})
		Colonies = append(Colonies, State{Num: 11, Name: "New York", Abbr: "NY", Capital: "Albany", Est: 1788, Pop: 19453561, Reps: 27})
		Colonies = append(Colonies, State{Num: 12, Name: "North Carolina", Abbr: "NC", Capital: "Raleigh", Est: 1789, Pop: 10488084, Reps: 13})
		Colonies = append(Colonies, State{Num: 13, Name: "Rhode Island", Abbr: "RI", Capital: "Providence", Est: 1790, Pop: 1059361, Reps: 2})


		// Define a second slice that will contain the "found" values for the requested search
		StatesFound := []State{}

		if r.Method == "POST" {
			IDStr := r.FormValue("ID") //Your form returns a string
			Abbr := r.FormValue("Abbr") //Your form returns a string
			CapitalString := r.FormValue("Capital") //Your form returns a string
			RepsString := r.FormValue("Reps") //Your form returns a string
			EstStartInt := r.FormValue("Est") //Your form returns a string
			EstEndInt := r.FormValue("Est") //Your form returns a string

			ID,_ :=strconv.ParseInt(IDStr,0,64) //convert string into int64
			Representative,_ :=strconv.ParseInt(RepsString,0,64) //convert string into int64
			Start,_ :=strconv.ParseInt(EstStartInt,0,64) //convert string into int64
			End,_ :=strconv.ParseInt(EstEndInt,0,64) //convert string into int64


			if IDStr != "" {
				for _,val := range Colonies{
					if val.Num == ID {
						StatesFound = append(StatesFound, val)
					} else {
						if strings.Contains(strings.TrimSpace(strings.ToLower(val.Abbr)), strings.TrimSpace(strings.ToLower(Abbr))) && Abbr!="" {
							StatesFound = append(StatesFound, val) 
						} else {
							if strings.Contains(strings.TrimSpace(strings.ToLower(val.Capital)), strings.TrimSpace(strings.ToLower(CapitalString))) && CapitalString!="" {
								StatesFound = append(StatesFound, val)
							} else {
								if val.Reps >= Representative && RepsString!=""  {
									StatesFound = append(StatesFound, val)
								} else {
									if val.Est == Start && EstStartInt!=""  {
										StatesFound = append(StatesFound, val)
									} else {
										if val.Est == End+1 && EstEndInt!="" {
											StatesFound = append(StatesFound, val)
											if val.Est == End+1 && val.Est == Start && EstStartInt < EstEndInt {
												End = Start;
												StatesFound = append(StatesFound, val)
											}

										}
									}
								}
							}
						}
					}
				}
			}
		} 
		tmpl.ExecuteTemplate(w, "listState2020.html", StatesFound)
	}


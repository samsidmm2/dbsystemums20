//Name: Sidney Sykes
// Course Number: CSCI475
// Assignment: Homework 4
// Honor Code: In keeping with the Honor Code of the University of Mississippi, I have neither given nor received inappropriate assistance on this assignment.

package main

//import packages
import (
  "database/sql"
  _ "github.com/go-sql-driver/mysql"
  "DBsykes"
  "log"
  "strconv"
  "net/http"
  "text/template"
)


func dbConn() (db *sql.DB) {
	
  //Call the two database.go functions, assigning to variables
  //NOTE: you must use the package name, DB<your last name>, when calling the functions.
  //Recall how you called string and math functions in the first Go homework

  Usr := DBsykes.Usr();
  Pwd := DBsykes.Pwd();
 
  db, err := sql.Open("mysql", Usr + ":" + Pwd + "@/"+ Usr)
  //Using these variables, establish a connection with your database
  //Call the handler db  - this is what you return below

  if err != nil {
        panic(err.Error())
  }
  return db
}

var tmpl = template.Must(template.ParseGlob("templates/*"))


func ChooseState2020(w http.ResponseWriter, r *http.Request) {
  type State struct {
  Num int64
  Name string
  Abbr string
  Capital string
  Est int64
  Pop int64
  Reps int64
}

	// Define a State slice called USStates
  USStates := []State{}

    db := dbConn();
	
	//NOTE:  This select statement assumes you still have a Formula table
    row, err := db.Query("SELECT Num, Name, Abbr, Capital, Year(Est) As Est, Reps FROM states Group By Reps Order By Reps")
    if err != nil {
        panic(err.Error())
    }

  for row.Next(){
      var Num, Est, Reps int64
      var Name, Abbr, Capital string

      err = row.Scan(&Num, &Name, &Abbr, &Capital, &Est, &Reps)

      if err != nil {
        panic(err.Error())
      }
      USStates = append(USStates,
         State{Num:Num, Name:Name, Abbr:Abbr, Capital:Capital, Est:Est, Reps:Reps})
  }

	tmpl.ExecuteTemplate(w, "chooseStateDB2020.html", USStates)
	defer db.Close()
}


  func ListState2020(w http.ResponseWriter, r *http.Request) {
    type State struct {
  Num int64
  Name string
  Abbr string
  Capital string
  Est int64
  Pop int64
  Reps int64
}

  // Define a State slice called USStates
  USStates := []State{}

      db := dbConn();

      if r.Method == "POST" {
      IDStr := r.FormValue("ID") //Your form returns a string
      StateStr := r.FormValue("name") //Your form returns a string
      AbbrStr := r.FormValue("abbr") //Your form returns a string
      CapitalStr := r.FormValue("capital") //Your form returns a string
      StartYearStr := r.FormValue("start") //Your form returns a string
      EndYearStr := r.FormValue("end") //Your form returns a string
      RepStr := r.FormValue("reps") //Your form returns a string

      if IDStr != "" {
      ID,_ :=strconv.ParseInt(IDStr,0,64) //convert string into int64
      //NOTE:  This select statement assumes you still have a Formula table
      row, err := db.Query("SELECT Num, Name, Abbr, Capital, Year(Est) As Est, Reps FROM states Where Num = ?", ID)

      if err != nil {
        panic(err.Error())
      }
      for row.Next() {
      var Num, Est, Reps int64
      var Name, Abbr, Capital string

      err = row.Scan(&Num, &Name, &Abbr, &Capital, &Est, &Reps)

      if err != nil {
        panic(err.Error())
      }
      USStates = append(USStates,
        State{Num:Num, Name:Name, Abbr:Abbr, Capital:Capital, Est:Est, Reps:Reps})
  }
       //end of the ifstr statement 
      } else {
      
      if StateStr != ""{
      stateName := "%" + StateStr + "%" //convert string into int64
      //NOTE:  This select statement assumes you still have a Formula table
      row, err := db.Query("SELECT Num, Name, Abbr, Capital, Year(Est) As Est, Reps FROM states Where Name LIKE ?", stateName)

      if err != nil {
        panic(err.Error())
      }
      for row.Next() {
      var Num, Est, Reps int64
      var Name, Abbr, Capital string

      err = row.Scan(&Num, &Name, &Abbr, &Capital, &Est, &Reps)

      if err != nil {
        panic(err.Error())
      }
      USStates = append(USStates,
        State{Num:Num, Name:Name, Abbr:Abbr, Capital:Capital, Est:Est, Reps:Reps})
  }
      // end of the StateStr
      } else {
     
    
    if AbbrStr != ""{
      abbrString := "%" + AbbrStr + "%" //convert string into int64
      //NOTE:  This select statement assumes you still have a Formula table
      row, err := db.Query("SELECT Num, Name, Abbr, Capital, Year(Est) As Est, Reps FROM states Where Abbr LIKE ?", abbrString)

      if err != nil {
        panic(err.Error())
      }
      for row.Next() {
      var Num, Est, Reps int64
      var Name, Abbr, Capital string

      err = row.Scan(&Num, &Name, &Abbr, &Capital, &Est, &Reps)

      if err != nil {
        panic(err.Error())
      }
      USStates = append(USStates,
        State{Num:Num, Name:Name, Abbr:Abbr, Capital:Capital, Est:Est, Reps:Reps})
  }
      // end of the AbbrStr
      } else {
        
      if CapitalStr != ""{
      capString := "%" + CapitalStr + "%" //convert string into int64
      //NOTE:  This select statement assumes you still have a Formula table
      row, err := db.Query("SELECT Num, Name, Abbr, Capital, Year(Est) As Est, Reps FROM states Where Capital = ?", capString)

      if err != nil {
        panic(err.Error())
      }
      for row.Next() {
      var Num, Est, Reps int64
      var Name, Abbr, Capital string

      err = row.Scan(&Num, &Name, &Abbr, &Capital, &Est, &Reps)

      if err != nil {
        panic(err.Error())
      }
      USStates = append(USStates,
        State{Num:Num, Name:Name, Abbr:Abbr, Capital:Capital, Est:Est, Reps:Reps})
  }
      // end of the CapitalStr
       
      } else {
    
      var Temp int64

      if StartYearStr != "" && EndYearStr != ""{
        YearStart,_ :=strconv.ParseInt(StartYearStr,0,64) //convert string into int64
        YearEnd,_ :=strconv.ParseInt(EndYearStr,0,64) //convert string into int64
          
        if YearStart > YearEnd {
          Temp = YearStart
          YearStart = YearEnd
          YearEnd = Temp
        }

      //NOTE:  This select statement assumes you still have a Formula table
      row, err := db.Query("SELECT Num, Name, Abbr, Capital, Year(Est) As Est, Reps FROM states Where Year(Est) >=? AND Year(Est) <=?", YearStart, YearEnd)

      if err != nil {
        panic(err.Error())
      }
      for row.Next() {
      var Num, Est, Reps int64
      var Name, Abbr, Capital string

      err = row.Scan(&Num, &Name, &Abbr, &Capital, &Est, &Reps)

      if err != nil {
        panic(err.Error())
      }
      USStates = append(USStates,
        State{Num:Num, Name:Name, Abbr:Abbr, Capital:Capital, Est:Est, Reps:Reps})
  }
      // end of the CapitalStr  
      
    } else {
    
     if RepStr != "" {
      Reps,_ :=strconv.ParseInt(RepStr,0,64) //convert string into int64 //convert string into int64

      //NOTE:  This select statement assumes you still have a Formula table
      row, err := db.Query("SELECT Num, Name, Abbr, Capital, Year(Est) As Est, Reps FROM states Where Reps = ? Order By Name ASC", Reps)

      if err != nil {
        panic(err.Error())
      }
      for row.Next() {
      var Num, Est, Reps int64
      var Name, Abbr, Capital string

      err = row.Scan(&Num, &Name, &Abbr, &Capital, &Est, &Reps)

      if err != nil {
        panic(err.Error())
      }
      USStates = append(USStates,
        State{Num:Num, Name:Name, Abbr:Abbr, Capital:Capital, Est:Est, Reps:Reps})
  }
      }
    }
         }
         }
          }
          } 
}
  tmpl.ExecuteTemplate(w, "listStateDB2020.html", USStates)
	defer db.Close()

  }


func main() {
	//Replace 1111 with your localhost
	//Replace **********  with your webid
    log.Println("Server started on: http://localhost:8110")
    http.HandleFunc("/", ChooseState2020)
    http.HandleFunc("/listStateDB2020.html", ListState2020)
    http.Handle("/home/swsykes/static/", http.StripPrefix("/home/swsykes/static/", http.FileServer(http.Dir("static"))))
    http.ListenAndServe(":8110", nil)
}


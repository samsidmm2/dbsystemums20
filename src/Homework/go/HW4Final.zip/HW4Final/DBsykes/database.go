package DBsykes

func Usr() string {
	return "swsykes";
}

func Pwd() string{
	return "olemiss2020";
	
}
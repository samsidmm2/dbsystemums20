package main

import (
  "log"
  "net/http"
  "text/template"
)

type Gamers struct {
       Name string
       Alias string
       Game string
       PrizePool string
}

var tmpl = template.Must(template.ParseGlob("templates/*"))

func ProGamers(w http.ResponseWriter, r*http.Request) {

GM := []Gamers{}
GM = append(GM, (Gamers{Name: "Emil", Alias: "Nyhrox",Game: "Fortnite", PrizePool: "64.4M"}))
GM = append(GM, (Gamers{Name: "Johan", Alias: "NOtail",Game: "Dota 2", PrizePool: "46.2M"}))
GM = append(GM, (Gamers{Name: "Andreas", Alias: "Xyp9x",Game: "Counter-Strike: Global Offensive", PrizePool: "21M"}))
GM = append(GM, (Gamers{Name: "Jeong", Alias: "Loki",Game: "PlayerUnknown's Battleground", PrizePool: "12.7M"}))
GM = append(GM, (Gamers{Name: "Jae", Alias: "Gesture",Game: "Overwatch", PrizePool: "9.1M"}))
GM = append(GM, (Gamers{Name: "Sang", Alias: "Faker",Game: "League of Legends", PrizePool: "9M"}))
GM = append(GM, (Gamers{Name: "Paulo", Alias: "PV",Game: "Magic: The Gathering", PrizePool: "8.9M"}))
GM = append(GM, (Gamers{Name: "Damon", Alias: "Karma",Game: "Call of Duty: Black Ops", PrizePool: "6.5M"}))
GM = append(GM, (Gamers{Name: "Nam", Alias: "Cat",Game: "Arena of Valor", PrizePool: "5.8M"}))
GM = append(GM, (Gamers{Name: "Sidney", Alias: "MaCrowav3r",Game: "Rainbow Six Siege", PrizePool: "4.1M"}))

 tmpl.ExecuteTemplate(w,"Gamers",GM) 
}

func main() {
    go log.Println("Server started on: http://localhost:8110")
    go http.HandleFunc("/",ProGamers)
    http.ListenAndServe(":8110", nil)
}
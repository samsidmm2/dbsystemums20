--Name: Sidney Sykes
--Course Number: CSCI475
--Assignment Number: 1 (Homework)
--In keeping with the Honor Code of the University of Mississippi, I have neither given nor received inappropriate assistance on this assignment.
-- This script creates a small Employeesloyee database

-- Create the new tables

-- Remove old tables, if they already exist.

DROP TABLE IF EXISTS Dept, Emp;

CREATE TABLE Emp(
          EID int NOT NULL PRIMARY KEY,
          ename varchar(50) NOT NULL,
          Age int NOT NULL,
		  Salary double,
		  DeptID int NOT NULL 
) Engine=InnoDB;

-- Note the use of Foreign key constraints.
-- The InnoDB engine is used for FK support

CREATE TABLE Dept (
          DeptID int NOT NULL PRIMARY KEY,
          DName varchar(50),
          budget double
) Engine=InnoDB;

insert into Emp values (229486 ,'Sykes, Sidney', 31, 65000.00, 180);
--SELECT @lastID := LAST_INSERT_ID();
insert into Dept values (180, 'Information Technology', 23456234.00);

insert into Emp values (223412 ,'Fox, Deitrick', 32, 57000.00, 181);
--SELECT @lastID := LAST_INSERT_ID();
insert into Dept values (181, 'Business', 43198234.00);

insert into Emp values (789948 ,'Doe, John', 26, 90000.00, 182);
--SELECT @lastID := LAST_INSERT_ID();
insert into Dept values (182, 'Health', 22335320.00);

insert into Emp values (434545 ,'Mindle, Lucas', 26, 45000.00, 183);
--SELECT @lastID := LAST_INSERT_ID();
insert into Dept values (183, 'Marketing', 32335334.00);

insert into Emp values (230172 ,'King, James', 31, 51000.00, 184);
--SELECT @lastID := LAST_INSERT_ID();
insert into Dept values (184, 'Human Resource', 19435246.00);

insert into Emp values (229486 ,'Jones, Stanley', 28, 67000.00, 185);
--SELECT @lastID := LAST_INSERT_ID();
insert into Dept values (185, 'Administration', 29435246.00);

SELECT * From Emp;

SELECT * from Dept;

SELECT * from Emp NATURAL JOIN Dept WHERE Salary<65000.00;



<!--Name: Sidney Sykes
// Course Number: CSCI475
// Assignment: Homework 3
// Honor Code: In keeping with the Honor Code of the University of Mississippi, I have neither given nor received inappropriate assistance on this assignment.
-->

<?php require_once("included_functions.php"); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<?php new_header("Pick Your State");?>

<?php
$states = ['one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen'];

$one = ['Num' => 1, 'Name' => 'Delaware', 'Abbr' => 'DE', 'Capital' => 'Dover', 'Est' => 1787, 'Pop' => 973764, 'Reps' => 1];
$two = ['Num' => 2, 'Name' => 'Pennsylvania', 'Abbr' => 'PA', 'Capital' => 'Harrisburg', 'Est' => 1787, 'Pop' => 12801989, 'Reps' => 18];
$three = ['Num' => 3, 'Name' => 'New Jersey', 'Abbr' => 'NJ', 'Capital' => 'Trenton', 'Est' => 1787, 'Pop' => 8882190, 'Reps' => 12];
$four = ['Num' => 4, 'Name' => 'Georgia', 'Abbr' => 'GA', 'Capital' => 'Atlanta', 'Est' => 1788, 'Pop' => 10617423, 'Reps' => 14];
$five = ['Num' => 5, 'Name' => 'Connecticut', 'Abbr' => 'CT', 'Capital' => 'Hartford', 'Est' => 1788, 'Pop' => 3565278, 'Reps' => 5];
$six = ['Num' => 6, 'Name' => 'Massachusetts', 'Abbr' => 'MA', 'Capital' => 'Boston', 'Est' => 1788, 'Pop' => 6892503, 'Reps' => 9];
$seven = ['Num' => 7, 'Name' => 'Maryland', 'Abbr' => 'MD', 'Capital' => 'Annapolis', 'Est' => 1788, 'Pop' => 6045680, 'Reps' => 8];
$eight = ['Num' => 8, 'Name' => 'South Carolina', 'Abbr' => 'SC', 'Capital' => 'Columbia', 'Est' => 1788, 'Pop' => 5148714, 'Reps' => 7];
$nine = ['Num' => 9, 'Name' => 'New Hampshire', 'Abbr' => 'NH', 'Capital' => 'Concord', 'Est' => 1788, 'Pop' => 1359711, 'Reps' => 2];
$ten = ['Num' => 10, 'Name' => 'Virginia', 'Abbr' => 'VA', 'Capital' => 'Richmond', 'Est' => 1788, 'Pop' => 8535519, 'Reps' => 11];
$eleven = ['Num' => 11, 'Name' => 'New York', 'Abbr' => 'NY', 'Capital' => 'Albany', 'Est' => 1788, 'Pop' => 19453561, 'Reps' => 27];
$twelve = ['Num' => 12, 'Name' => 'North Carolina', 'Abbr' => 'NC', 'Capital' => 'Raleigh', 'Est' => 1789, 'Pop' => 10488084, 'Reps' => 13];
$thirteen = ['Num' => 13, 'Name' => 'Rhode Island', 'Abbr' => 'RI', 'Capital' => 'Providence', 'Est' => 1790, 'Pop' => 1059361, 'Reps' => 2];

?>

<form method="POST" action="listState2020.php">
	<div class="row">
		<label for="left-label" class="left inline">
			<h2>Pick Your State</h2>
			Choose The State of Statehood:<select name="ID">
			<option></option>
			<?php 
			foreach($states as $state) {	
			?>
			<option value= "<?php echo $state; ?>"><?php echo ${$state}['Num'];?></option>
			<?php
}
?>
		     </select>
		     <p /><hr>&nbsp;&nbsp;&nbsp;<b>OR</b>&nbsp;&nbsp;&nbsp;fill in zero or more values below<hr
		     <p>State Abbreviation: <input type=text name="Abbr"></p>
		     <p>Capital: <input type=text name="Capital"></p>
			Choose The Number of House of Representatives:<select name="Representative">
			<option></option>
			<?php 
			foreach($states as $oneState) {	
			?>
			<option value= "<?php echo $oneState; ?>"><?php echo ${$oneState}['Reps'];?></option>
			<?php
}
?>
		     </select>
		     <p>Starting Year Established: <input type=text name="EstStartYear"></p>
			 <p>Ending Year Established: <input type=text name="EstEndYear"></p>


		<input type="submit" name="submit" class="button tiny round" value="Find a State" />
		</label>		
	</div>	
</form>
<?php new_footer("Sidney Sykes"); ?>
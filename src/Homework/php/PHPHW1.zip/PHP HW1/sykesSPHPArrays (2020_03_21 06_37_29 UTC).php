<!--
Name: Sidney Sykes
Course Number: CSCI475
Assignment Number: 3 (PHP Homework)
In keeping with the Honor Code of the University of Mississippi, I have neither given nor received inappropriate assistance on this assignment.
 -->
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php  
	$alias = ['Nyhrox', 'NOtail', 'Xyp9x', 'Loki', 'Gesture', 'Faker', 'PV', 'Karma', 'Cat','MaCrowav3r'];

	$Nyhrox = ['name' => 'Emil', 'game' => 'Fortnite', 'pool' => '64.4M'];
	$NOtail = ['name' => 'Johan', 'game' => 'Dota 2', 'pool' => '46.2M'];
	$Xyp9x = ['name' => 'Andreas', 'game' => 'Counter-Strike: Global Offensive', 'pool' => '21M'];
	$Loki = ['name' => 'Jeong', 'game' => "PlayerUnknowns Batleground's", 'pool' => '12.7M'];
	$Gesture = ['name' => 'Jae', 'game' => 'Overwatch', 'pool' => '9.1M'];
	$Faker = ['name' => 'Sang', 'game' => 'League of Legends', 'pool' => '9M'];
	$PV = ['name' => 'Paulo', 'game' => 'Magic: The Gathering', 'pool' => '8.9M'];
	$Karma = ['name' => 'Damon', 'game' => 'Call of Duty: Black Ops 4', 'pool' => '6.5M'];
	$Cat = ['name' => 'Nam', 'game' => 'Arena of Valor', 'pool' => '5.8M'];
	$MaCrowav3r = ['name' => 'Sidney', 'game' => 'Rainbow Six Siege', 'pool' => '4.1M'];


	foreach($alias as $oneAlias) {
		echo "Name: ".${$oneAlias}['name']." "."(".$oneAlias.")"."<br />";
		echo "Game: ".${$oneAlias}['game']." "."with Prize Pool"." ".${$oneAlias}['pool']."<br /><hr />";
	}
	?>
</body>
</html>
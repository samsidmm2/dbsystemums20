<?php require_once("included_functions.php");
require_once("database.php");
	// Add require_once function calls as you did in take-home quiz
	// Also set up connecting to your database
	  $mysqli=Database::dbConnect();
	  $mysqli->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

?>

<!--Name: Sidney Sykes
// Course Number: CSCI475
// Assignment: Lab 8
// Honor Code: In keeping with the Honor Code of the University of Mississippi, I have neither given nor received inappropriate assistance on this assignment.
-->

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">

<html lang="en">
	<?php new_header("Pick Your State"); ?>

    <form method="POST" action="listStateDB2020.php">
	    <div class="row">
		  <label for="left-label" class="left inline">

			<h2>Pick Your State</h2>
			Choose the Order of Statehood:<select name="ID">
			<option></option>
			<?php
			//*******************  Add Code here to choose states *******************
			$stmt = $mysqli -> prepare("SELECT Num from states Order By Num ASC");
			$stmt -> execute();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				echo "<option value= '".$row['Num']."'>".$row['Num']."</option>";
			}					
			?>			
			</select><p />	
			<hr>&nbsp;&nbsp;&nbsp;<b>OR</b> &nbsp;&nbsp;&nbsp; fill in zero or more values below<hr> <p />
			<p>State: <input type=text name="Name"></p>
			 <p>State Abbreviation: <input type=text name="Abbr"></p>
		     <p>Capital: <input type=text name="Capital"></p>

			<!--Choose House of Representative-->
			Choose The Number of House of Representatives:<select name="Reps">
			<option></option>
			<?php
			//*******************  Add Code here to choose states *******************
			$stmt = $mysqli ->prepare("SELECT Reps from states");
			$stmt -> execute();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				echo "<option value= '".$row['Reps']."'>".$row['Reps']."</option>";
			}					
			?>			
			</select><p />
			<!------------------------------------------------------------------------------->
			Start Establishment:<select name="StartEst">
			<option></option>
			<?php
			//*******************  Add Code here to choose states *******************
			$stmt = $mysqli ->prepare("SELECT Distinct Year(Est) as Est from states");
			$stmt -> execute();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				echo "<option value= '".$row['Est']."'>".$row['Est']."</option>";
			}					
			?>			
			</select><p />
			<!------------------------------------------------------------------------------>
			End Establishment:<select name="EndEst">
			<option></option>
			<?php
			//*******************  Add Code here to choose states *******************
			$stmt = $mysqli ->prepare("SELECT Distinct Year(Est) as Est from states");
			$stmt -> execute();
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
				echo "<option value= '".$row['Est']."'>".$row['Est']."</option>";
			}					
			?>			
			</select><p />
		  <input type="submit" name="submit" class="button tiny round" value="Find a State" />
		  </label>
      </div>
    </form>
<?php new_footer("Sidney Sykes"); 
    //$stmt -> close();
    Database::dbDisconnect();
?>

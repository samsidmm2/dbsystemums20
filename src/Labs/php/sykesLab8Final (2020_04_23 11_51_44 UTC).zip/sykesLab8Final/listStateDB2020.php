<?php require_once("included_functions.php");
require_once("database.php");

	// Add require_once function calls as you did in take-home quiz
	// Also set up connecting to your database
	  $mysqli=Database::dbConnect();
	  $mysqli->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

	// Function to display one state's information
	function printStateInfo($s){
		echo "<tr>";
		echo "<td style='text-align:center'>".$s["Name"]."</td>";
		echo "<td style='text-align:center'>".$s["Capital"]."</td>";
		echo "<td style='text-align:center'>".$s["Abbr"]."</td>";
		echo "<td style='text-align:center'>".$s["Num"]."</td>";
		echo "<td style='text-align:center'>".$s["Est"]."</td>";
		echo "<td style='text-align:center'>".$s["Reps"]."</td>";
		echo "</tr>";
	}
?>

<!--Name: Sidney Sykes
// Course Number: CSCI475
// Assignment: Lab 8
// Honor Code: In keeping with the Honor Code of the University of Mississippi, I have neither given nor received inappropriate assistance on this assignment.
-->
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">

<html lang="en">
<?php new_header("States"); ?>

<div class="row">
<label for="left-label" class="left inline">
<h2>Here is/are Your State(s)</h2>
<?php
	//*******************  Add Code here to list states *******************
echo "<table border = '1'>";
echo "<thead><tr><th>State</th><th>Capital</th><th>Abbreviation</th><th>Order of 
Statehood(s)</th><th>Established</th><th>Number of House of 
Representatives</th></tr></thead>";
echo "<tbody>";

if(isset($_POST['ID']) && $_POST['ID'] !== "") {
	$ID = $_POST['ID'];
	$query = "SELECT Name, Num, Abbr, Capital, Year(Est) as Est, Reps from states where Num =? Order By Num ASC";
	$stmt = $mysqli -> prepare($query);
	$stmt -> execute([$ID]);

	while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		printStateInfo($row);
	}

}

echo "</tbody>";
echo "</table>";
?>
</label>
</div>
<?php new_footer("Sidney Sykes"); 
	//$stmt -> close();
    Database::dbDisconnect();
?>
--Name: Sidney Sykes
--Course Number: CSCI475
--Assignment Number: 2 (Lab)
--In keeping with the Honor Code of the University of Mississippi, I have neither given nor received inappropriate assistance on this assignment.
-- This script creates a small Employees database with joinings

SELECT * from STORE_Lab2 natural join REGION_Lab2 where REGION_DESCRIPT = 'East';
SELECT STORE_NAME from STORE_Lab2 natural join REGION_Lab2 where REGION_DESCRIPT = 'East';
SELECT * from STORE_Lab2 natural join REGION_Lab2 where REGION_DESCRIPT = 'West';
SELECT EMP_LNAME from EMPLOYEE_Lab2 left outer join STORE_Lab2 on EMPLOYEE_Lab2.STORE_CODE = STORE_Lab2.STORE_CODE;
SELECT EMP_LNAME from EMPLOYEE_Lab2 left outer join STORE_Lab2 on EMPLOYEE_Lab2.STORE_CODE = STORE_Lab2.STORE_CODE natural join REGION_Lab2 where REGION_DESCRIPT = 'East';
SELECT EMP_LNAME from EMPLOYEE_Lab2 left outer join STORE_Lab2 on EMPLOYEE_Lab2.STORE_CODE = STORE_Lab2.STORE_CODE natural join REGION_Lab2 where REGION_DESCRIPT = 'West';
SELECT EMP_LNAME from EMPLOYEE_Lab2 left outer join STORE_Lab2 on EMPLOYEE_Lab2.STORE_CODE = STORE_Lab2.STORE_CODE natural join REGION_Lab2 where REGION_DESCRIPT = 'East' and EMP_DOB < '1975-02-05';
SELECT EMP_LNAME from EMPLOYEE_Lab2 left outer join STORE_Lab2 on EMPLOYEE_Lab2.STORE_CODE = STORE_Lab2.STORE_CODE natural join REGION_Lab2 where REGION_DESCRIPT = 'West' and EMP_DOB > '1970-02-05';
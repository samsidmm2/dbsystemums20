<!--Name: Sidney Sykes
// Course Number: CSCI475
// Assignment: Lab 10
// Honor Code: In keeping with the Honor Code of the University of Mississippi, I have neither given nor received inappropriate assistance on this assignment.
-->
<?php 

//Add beginning code to 
//1. Require the needed 3 files
//2. Connect to your database
//3. Output a message, if there is one
	require_once("session.php"); 
	require_once("included_functions.php");
	require_once("database.php");
	verify_login();


	new_header("Here is Who's Who!"); 
	$mysqli = Database::dbConnect();
	$mysqli -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	if (($output = message()) !== null) {
		echo $output;
	}

		echo "<h3>Update to Who's who!</h3>";
	echo "<div class='row'>";
	echo "<label for='left-label' class='left inline'>";
	
  	if (isset($_GET["id"]) && $_GET["id"] !== "") {
//////////////////////////////////////////////////////////////////////////////////////				
	  //Prepare and execute a query to DELETE FROM using GET id in criterion - WHERE PersonID = ?
	  	$PersonID = $_GET["id"];
	  	$query = "DELETE FROM people Where PersonID = ?";
		$stmt = $mysqli -> prepare($query);
	  	$stmt -> execute([$PersonID]);
	  	  //Prepare and execute a query to SELECT * using GET id in criterion - WHERE PersonID = ?
	  	//$query = "SELECT * from people Where PersonID = ?";
	  	//$stmt = $mysqli -> prepare($query);
	  	//$stmt -> execute([$PersonID]);
	  
		if ($stmt) {
			//Create SESSION message that Person successfully deleted

			$_SESSION["message"] = $["FirstName"]." ".$["LastName"]." has been deleted";
			
		}
		else {
			//Create SESSION message that Person could not be deleted

			$_SESSION["message"] = "Error! Could not be deleted ".$["FirstName"]." ".$["LastName"];
		}
		
		//************** Redirect to readPeople.php
		redirect("readPeople.php");
		
//////////////////////////////////////////////////////////////////////////////////////				
	}
	else {
		$_SESSION["message"] = "Person could not be found!";
		//header("Location: readPeople.php");
		//exit;
		redirect("readPeopleSOLN.php");
	}

		echo "<br /><br /><a href='createPeople.php'>Add a person</a> | <a href='addLogin.php'>Add an admin</a> | <a href='logout.php'>Logout</a>";
		echo "</center>";
		echo "</div>";
		
			
//Define footer with the phrase "Who's Who"
//Release query results
//Close database
    new_footer("Who's Who");
	//$stmt -> close();

	
	Database::dbDisconnect();
?>
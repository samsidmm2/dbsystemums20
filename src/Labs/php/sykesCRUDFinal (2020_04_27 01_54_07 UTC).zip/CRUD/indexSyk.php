<?php 
//Add beginning code to 
//1. Require the needed 3 files
//2. Connect to your database
//3. Output a message, if there is one
	require_once("session.php"); 
	require_once("included_functions.php");
	require_once("database.php");



new_header("Who's who!"); 
	$mysqli = Database::dbConnect();
	$mysqli -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	if (($output = message()) !== null) {
		echo $output;
	}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//     Step 7.  Check whether username and password have been submitted from the index form. Verify the values are not empty
//				Some of this code may be borrowed from addLogin.php
	if (isset($_POST["submit"])) {

	    //Grab posted values for username and password.  
		//IMPORTANT CHANGE:  Unlike in addLogin.php, you will NOT encrypt password
		//Once we check if the username exists, we will do the encryption in 
		//the function password_check, which returns true if the passwords match
		
		$username = $_POST["username"];
		$password = $_POST["password"];
 		$query = "SELECT * from admins  where username =?";
		$stmt = $mysqli -> prepare($query);
		$stmt -> execute([$username]);

		//Check to make sure user does not already exist

		/*
		if($stmt>1) {
		$_SESSION["message"] = "The username already exists";
		password_check($password, $existing_hash);
		
		} 
		*/
		
		//NOTE:  This part differs from addLogin.php
		//Username found so now check password
		//If the attempted password matches the database password then set two $_SESSION variables
		//$_SESSION["username"]  & $_SESSION[admin"]
		//Redirect to readPeople.php

		if ($stmt) {
			
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$pw_check = password_check($password, $row['hashed_password']);
			if($pw_check){
				$match_check = $row['hashed_password'];
					 $_SESSION["username"] = $username;
 					 $_SESSION["admin"] = $admin ;
			}


		}
		
		redirect("readPeople.php");
	    }
		
		//If the attempted password DOES NOT match the database password, create a session 
		//message -> "Username/Password could not be found"
		//Redirect to indexABC.php   where ABC are the first 3 letters of your last name
 	    else {
 	    	$_SESSION["message"] = "The username/password could not be found";
	  		redirect("indexSyk.php");
	    }

	  	redirect("addLogin.php");

	}  
///////////////////////////////////////////////////////////////////////////////////////////////////////

?>

		<div class='row'>
		<label for='left-label' class='left inline'>
	
		<h3>Welcome!</h3>
		
<!--//////////////////////////////////////////////////////////////////////////////////////////////// -->
<!--    Step 6. Create textboxes for Login -->
<!--            Note:  you can copy and paste from addLogin.php.  Just be sure to change -->
<!--                   action = "addLogin.php"    to action = "indexABC.php"  where ABC are the first 3 letters of your last name -->   
		<form action="indexSyk.php" method="post">
		<p>Username: <input type="text" name="username" value="" /></p>
		<p>Password: <input type="password" name="password" value="" /></p>
		<input type="submit" name="submit" value="Add Administrator">
	</form>		
			
			
			
			
			

<!--//////////////////////////////////////////////////////////////////////////////////////////////// -->
				
	</div>
	</label>

<?php 
//Define footer with the phrase "Who's Who"
//Release query results
//Close database
	new_footer("Who's Who");
	//$stmt -> close();

	
	Database::dbDisconnect();
 ?>

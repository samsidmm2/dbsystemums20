<?php 
//Name: Sidney Sykes
// Course Number: CSCI475
// Assignment: Quiz 5
// Honor Code: In keeping with the Honor Code of the University of Mississippi, I have neither given nor received inappropriate assistance on this assignment.


//Add beginning code to 
//1. Require the needed 3 files
//2. Connect to your database
	require_once("session.php"); 
	require_once("included_functions.php");
	require_once("database.php");
	verify_login();

new_header("Delete from Who's who!"); 
		$mysqli = Database::dbConnect();
	$mysqli -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
///////////////////////////////////////////////////////////////////////////////////
//  Step 9  -  invoke verify_login
//			   Will redirect to indexABC.php if there is not a SESSION admin_id set   
//             NOTE:  REPLACE ABC with the first 3 letters of your last name


///////////////////////////////////////////////////////////////////////////////////

//3. Output a message, if there is one
	if (($output = message()) !== null) {
		echo $output;
	}
///////////////////////////////////////////////////////////////////////////////////
// Step 5.  Get this admins ID and delete from the database
 if (isset($_GET["id"]) && $_GET["id"] !== "") {
		//$adminID = $_GET["id"];
// Execute query and create a session message
// If successful (i.e., $stmt is true), output "Successfully deleted user"
// If unsuccessful, output "Unable to delete user"
 		
 		$query = "DELETE FROM admins Where id = ?";
 		$stmt = $mysqli -> prepare($query);
		
	  	$stmt -> execute([$_GET["id"]]);

	 if ($stmt) {
			//Create SESSION message that User successfully deleted
			$_SESSION["message"] = "Successfully deleted user";	
			redirect("addLogin.php");	
		}
		else {
			//Create SESSION message that Person could not be deleted
			$_SESSION["message"] = "Unable to delete user ";
				redirect("addLogin.php");
		}

//////////////////////////////////////////////////////////////////////////////////
		//redirect("addLogin.php");

	}
	redirect("addLogin.php");
//Define footer with the phrase "Who's Who"
//Release query results
//Close database
	new_footer("Who's Who");
	//$stmt -> close();

	
	Database::dbDisconnect();
?>